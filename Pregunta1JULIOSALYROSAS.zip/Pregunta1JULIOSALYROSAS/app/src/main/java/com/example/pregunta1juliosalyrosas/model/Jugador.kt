package com.example.pregunta1juliosalyrosas.model

class Jugador {
}